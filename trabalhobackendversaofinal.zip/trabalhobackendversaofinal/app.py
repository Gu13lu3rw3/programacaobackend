from flask import Flask
from routes.rotas import adicionar_rotas

app = Flask(__name__)

adicionar_rotas(app)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)