from controllers.controllers import (
    inicio, jogar, responder,
    gerenciar, criar, editar, deletar
)

def adicionar_rotas(app):
    app.add_url_rule(rule='/', endpoint='inicio', view_func=inicio, method=["GET"])
    app.add_url_rule(rule='/jogar', endpoint='jogar', view_func=jogar, method=["GET"])
    app.add_url_rule(rule='/responder', endpoint='responder', view_func=responder, methods=["POST"])
    app.add_url_rule(rule='/gerenciar', endpoint='gerenciar', view_func=gerenciar, methods=["GET"])
    app.add_url_rule(rule='/criar', endpoint='criar', view_func=criar, methods=["GET", "POST"])
    app.add_url_rule(rule='/editar/<id>', endpoint='editar', view_func=editar, methods=["GET", "POST"])
    app.add_url_rule(rule='/deletar/<id>', endpoint='deletar', view_func=deletar, methods=["GET"])