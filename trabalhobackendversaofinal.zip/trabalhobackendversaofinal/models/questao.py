class Questao:
    def __init__(self, id, pergunta, alternativaA, alternativaB, alternativaC, respostaCorreta):
        self.id = id
        self.pergunta = pergunta
        self.alternativaA = alternativaA
        self.alternativaB = alternativaB
        self.alternativaC = alternativaC
        self.respostaCorreta = respostaCorreta

    def validar(self):
        erros = []

        if not self.pergunta or len(self.pergunta) < 5:
            erros.append("O enunciado deve ter no mínimo 5 caracteres!")
        if not self.alternativaA or len(self.alternativaA) < 2:
            erros.append("As alternativas devem ter pelo menos 2 caracteres!")
        if not self.alternativaB or len(self.alternativaB) < 2:
            erros.append("As alternativas devem ter pelo menos 2 caracteres!")
        if not self.alternativaC or len(self.alternativaC) < 2:
            erros.append("As alternativas devem ter pelo menos 2 caracteres!")
        if self.respostaCorreta not in ["a", "b", "c"]:
            erros.append('Resposta correta deve ser a, b ou c')
        if self.alternativaA == self.alternativaB or self.alternativaA == self.alternativaB or self.alternativaB == self.alternativaC:
            erros.append('As alternativas não podem ser iguais')

        return erros
    
class Gerenciador:
    def __init__(self):
        self.questoes = []
        self.proximo_id = 1
        self.carregar_questao()
    
    def carregar_questao(self):
        q1 = Questao (1,
        "Qual é a capital do Brasil atualmente?,"
        "Brasília",
        "São Paulo",
        "Rio de Janeiro", "a")

        q2 = Questao(2,
        "Qual é o maior planeta do Sistema Solar?," \
        "Saturno," \
        "Marte",
        "Júpiter", "c")

        q3 = Questao(3,
        "Quantos anos viveu Matusalém?",
        "588",
        "969",
        "120", "b")

        self.questoes.append(q1)
        self.questoes.append(q2)
        self.questoes.append(q3)
        self.proximo_id = 4

    def criar_questao(self, pergunta, alternativaA, alternativaB, alternativaC, respostaCorreta):
        nova_questao = Questao(self.proximo_id, pergunta, alternativaA, alternativaB, alternativaC, respostaCorreta)

        erros = nova_questao.validar()
        if erros:
            return {"sucesso": False, "erros": erros}
        
        self.questoes.append(nova_questao)
        self.proximo_id += 1
        return {"sucesso": True, "mensagem": "Questão criada com sucesso!"}
    
    def listar_questao(self):
        return self.questoes
    
    def achar_questao_porID(self, id):
        for questao in self.questoes:
            if questao.id == id:
                return questao
        return None
    
    def editar_questao(self, id, pergunta, alternativaA, alternativaB, alternativaC, respostaCorreta):
        questao = self.achar_questao_porID(id)
        if not questao:
            return {"sucesso": False, "erros": ["Questão não encontrada!"]}
        
        questao.pergunta = pergunta
        questao.alternativaA = alternativaA
        questao.alternativaB = alternativaB
        questao.alternativaC = alternativaC
        questao.respostaCorreta = respostaCorreta

        erros = questao.validar()
        if erros:
            return {"sucesso": False, "erros": erros}
        
        return {"sucesso": True, "mensagem": "Questão editada com sucesso!"}

    def deletar(self, id):
        for i, questao in enumerate(self.questoes):
            if questao.id == id:
                self.questoes.pop(i)
                return {"sucesso": True, "mensagem": "Questão deletada com sucesso!"}
        return {"sucesso": False, "erros": ["Questão não encontrada"]}
    
    