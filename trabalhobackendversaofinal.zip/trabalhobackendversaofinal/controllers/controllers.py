from flask import render_template, request
import random
from models.questao import Gerenciador

gerenciador = Gerenciador()

pontuacao = {'perguntas': 0, 'acertos': 0, 'erros': 0}
pergunta_atual = None
resposta_usuario_atual = None

def inicio():
    questoes = gerenciador.listar_questao()
    return render_template('tela_inicio.html', questoes=questoes, pontuacao=pontuacao)

def jogar():
    global pergunta_atual
    
    questoes = gerenciador.listar_questao()
    if len(questoes) == 0:
        return 'Nenhuma pergunta disponivel'
    
    pergunta_atual = random.choice(questoes)
    
    return render_template(
        'jogo.html',
        pergunta=pergunta_atual,
        pontuacao=pontuacao
    )

def responder():
    global pergunta_atual, resposta_usuario_atual
    
    resposta_usuario_atual = request.form.get('resposta')
    resposta_correta = pergunta_atual.respostaCorreta
    
    pontuacao['perguntas'] += 1
    
    if resposta_usuario_atual == resposta_correta:
        resultado = 'Voce acertou!'
        pontuacao['acertos'] += 1
    else:
        resultado = 'Voce errou!'
        pontuacao['erros'] += 1
    
    return render_template(
        'resultado.html',
        resultado=resultado,
        pergunta=pergunta_atual,
        resposta_usuario=resposta_usuario_atual,
        resposta_correta=resposta_correta,
        pontuacao=pontuacao
    )

def gerenciar():
    questoes = gerenciador.listar_questao()
    return render_template('gerenciar.html', questoes=questoes)

def criar():
    if request.method == 'POST':
        pergunta = request.form.get('pergunta')
        alternativaA = request.form.get('alternativaA')
        alternativaB = request.form.get('alternativaB')
        alternativaC = request.form.get('alternativaC')
        respostaCorreta = request.form.get('respostaCorreta')
        
        resultado = gerenciador.criar(pergunta, alternativaA, alternativaB, alternativaC, respostaCorreta)
        
        if resultado['sucesso']:
            mensagem = resultado['mensagem']
            tipo = 'sucesso'
        else:
            mensagem = ', '.join(resultado['erros'])
            tipo = 'erro'
        
        return render_template(
            'form.html',
            mensagem=mensagem,
            tipo=tipo,
            acao='Criar'
        )
    
    return render_template('form.html', acao='Criar')

def editar(id):
    questao = gerenciador.achar_questao_porID(int(id))
    
    if not questao:
        return 'Questao nao encontrada'
    
    if request.method == 'POST':
        pergunta = request.form.get('pergunta')
        alternativaA = request.form.get('alternativaA')
        alternativaB = request.form.get('alternativaB')
        alternativaC = request.form.get('alternativaC')
        respostaCorreta = request.form.get('respostaCorreta')
        
        resultado = gerenciador.editar(int(id), pergunta, alternativaA, alternativaB, alternativaC, respostaCorreta)
        
        if resultado['sucesso']:
            mensagem = resultado['mensagem']
            tipo = 'sucesso'
        else:
            mensagem = ', '.join(resultado['erros'])
            tipo = 'erro'
        
        return render_template(
            'form.html',
            questao=questao,
            mensagem=mensagem,
            tipo=tipo,
            acao='Editar'
        )
    
    return render_template(
        'form.html',
        questao=questao,
        acao='Editar'
    )

def deletar(id):
    resultado = gerenciador.deletar(int(id))
    questoes = gerenciador.listar_questao()
    
    mensagem = resultado['mensagem'] if resultado['sucesso'] else resultado['erros'][0]
    tipo = 'sucesso' if resultado['sucesso'] else 'erro'
    
    return render_template(
        'gerenciar.html',
        questoes=questoes,
        mensagem=mensagem,
        tipo=tipo
    )