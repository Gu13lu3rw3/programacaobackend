document.addEventListener('DOMContentLoaded', function() {
    const opcoes = document.querySelectorAll('.opcao');
    
    opcoes.forEach(opcao => {
        opcao.addEventListener('click', function() {
            const radio = this.querySelector('input[type="radio"]');
            if (radio) {
                radio.checked = true;
            }
        });
    });
});